tellraw @a {text:"已加载rks_lite数据包for 1.21.11+, v2.3",color:"yellow" }
tellraw @a {text:"玩得开心，欢迎反馈！",color:"yellow" }
scoreboard objectives add joined dummy
scoreboard objectives add life dummy
scoreboard objectives add sat dummy
scoreboard objectives add ward dummy